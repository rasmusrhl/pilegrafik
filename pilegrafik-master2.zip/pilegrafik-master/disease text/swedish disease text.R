Laebe_1year_male_10_sygdomstekst                                                               <-             �"F�rb�ttring i 1-�rs cancer�verlevnad, NORDCAN\n L�pp, m�nn"
Mundhule_1year_male_20_sygdomstekst                                                            <-             �"F�rb�ttring i 1-�rs cancer�verlevnad, NORDCAN\n Tunga, m�nn"
Spytkirtel_1year_male_30_sygdomstekst                                                          <-             �"F�rb�ttring i 1-�rs cancer�verlevnad, NORDCAN\n Spottk�rtel, m�nn"
Oropharynx_1year_male_40_sygdomstekst                                                          <-             �"F�rb�ttring i 1-�rs cancer�verlevnad, NORDCAN\n Mellansvalg, m�nn"
Nasopharynx_1year_male_41_sygdomstekst                                                         <-             �"F�rb�ttring i 1-�rs cancer�verlevnad, NORDCAN\n �vre svalgrum, m�nn"
Hypopharynx_1year_male_50_sygdomstekst                                                         <-             �"F�rb�ttring i 1-�rs cancer�verlevnad, NORDCAN\n Nedre svalg, m�nn"
Pharynx_daarligt_defineret_1year_male_51_sygdomstekst                                          <-             �"F�rb�ttring i 1-�rs cancer�verlevnad, NORDCAN\n Svalg, ofullst�ndigt angiven, m�nn"
Spiseror_1year_male_60_sygdomstekst                                                            <-             �"F�rb�ttring i 1-�rs cancer�verlevnad, NORDCAN\n Matstrupe, m�nn"
Mave_1year_male_70_sygdomstekst                                                                <-             �"F�rb�ttring i 1-�rs cancer�verlevnad, NORDCAN\n Mags�ck, m�nn"
Tyndtarm_1year_male_80_sygdomstekst                                                            <-             �"F�rb�ttring i 1-�rs cancer�verlevnad, NORDCAN\n Tunntarm, m�nn"
Tyktarm_1year_male_90_sygdomstekst                                                             <-             �"F�rb�ttring i 1-�rs cancer�verlevnad, NORDCAN\n Tjocktarm, m�nn"
Endetarm_og_anus_1year_male_100_sygdomstekst                                                   <-             �"F�rb�ttring i 1-�rs cancer�verlevnad, NORDCAN\n �ndtarm och anus, m�nn"
Lever_1year_male_110_sygdomstekst                                                              <-             �"F�rb�ttring i 1-�rs cancer�verlevnad, NORDCAN\n Lever, m�nn"
Galdeblaere_og_galdeveje_1year_male_120_sygdomstekst                                           <-             �"F�rb�ttring i 1-�rs cancer�verlevnad, NORDCAN\n Gallbl�sa och gallv�gar, m�nn"
Bugspytkirtel_1year_male_130_sygdomstekst                                                      <-             �"F�rb�ttring i 1-�rs cancer�verlevnad, NORDCAN\n Bukspottk�rtel, m�nn"
Naese_og_bihuler_1year_male_140_sygdomstekst                                                   <-             �"F�rb�ttring i 1-�rs cancer�verlevnad, NORDCAN\n N�sh�la och bih�lor, m�nn"
Strube_1year_male_150_sygdomstekst                                                             <-             �"F�rb�ttring i 1-�rs cancer�verlevnad, NORDCAN\n Struphuvud, m�nn"
Lunge_inkl_luftror_1year_male_160_sygdomstekst                                                 <-             �"F�rb�ttring i 1-�rs cancer�verlevnad, NORDCAN\n Lunga (inkl. luftstrupe och luftr�r), m�nn"
Lungehinde_1year_male_170_sygdomstekst                                                         <-             �"F�rb�ttring i 1-�rs cancer�verlevnad, NORDCAN\n Lungs�ck, m�nn"
Bryst_1year_male_180_sygdomstekst                                                              <-             �"F�rb�ttring i 1-�rs cancer�verlevnad, NORDCAN\n Br�st, m�nn"
Livmoderhals_1year_male_190_sygdomstekst                                                       <-             �"F�rb�ttring i 1-�rs cancer�verlevnad, NORDCAN\n Livmoderhals, m�nn"
Livmoder_1year_male_200_sygdomstekst                                                           <-             �"F�rb�ttring i 1-�rs cancer�verlevnad, NORDCAN\n Livmoderkropp, m�nn"
Livmoder_uden_specifikation_1year_male_210_sygdomstekst                                        <-             �"F�rb�ttring i 1-�rs cancer�verlevnad, NORDCAN\n Livmoder, ospecificerat st�lle, m�nn"
Aeggestok_aeggeleder_mv_1year_male_220_sygdomstekst                                            <-             �"F�rb�ttring i 1-�rs cancer�verlevnad, NORDCAN\n �ggstock, �ggledare och breda livmoderbanden, m�nn"
Ovrige_kvindelige_konsorganer_1year_male_230_sygdomstekst                                      <-             �"F�rb�ttring i 1-�rs cancer�verlevnad, NORDCAN\n �vriga kvinnliga k�nsorgan, m�nn"
Prostata_1year_male_240_sygdomstekst                                                           <-             �"F�rb�ttring i 1-�rs cancer�verlevnad, NORDCAN\n Prostata, m�nn"
Testikel_1year_male_250_sygdomstekst                                                           <-             �"F�rb�ttring i 1-�rs cancer�verlevnad, NORDCAN\n Testikel, m�nn"
Penis_og_andre_mandlige_konsorganer_1year_male_260_sygdomstekst                                <-             �"F�rb�ttring i 1-�rs cancer�verlevnad, NORDCAN\n Penis och �vriga manliga k�nsorgan, m�nn"
Nyre_1year_male_270_sygdomstekst                                                               <-             �"F�rb�ttring i 1-�rs cancer�verlevnad, NORDCAN\n Njure inklusive njurb�cken, m�nn"
Blaere_og_andre_urinveje_1year_male_280_sygdomstekst                                           <-             �"F�rb�ttring i 1-�rs cancer�verlevnad, NORDCAN\n Urinbl�sa och �vriga urinv�gar, m�nn"
Modermaerkekraeft_hud_1year_male_290_sygdomstekst                                              <-             �"F�rb�ttring i 1-�rs cancer�verlevnad, NORDCAN\n Malignt melanom i huden, m�nn"
Anden_hud_ikke_modermaerke_1year_male_300_sygdomstekst                                         <-             �"F�rb�ttring i 1-�rs cancer�verlevnad, NORDCAN\n Hud, icke malignt melanom, m�nn"
Oje_1year_male_310_sygdomstekst                                                                <-             �"F�rb�ttring i 1-�rs cancer�verlevnad, NORDCAN\n �ga, m�nn"
Hjerne_og_centralnervesystem_1year_male_320_sygdomstekst                                       <-             �"F�rb�ttring i 1-�rs cancer�verlevnad, NORDCAN\n Hj�rna och �vriga nervsystemet, m�nn"
Skjoldbruskkirtel_1year_male_330_sygdomstekst                                                  <-             �"F�rb�ttring i 1-�rs cancer�verlevnad, NORDCAN\n Sk�ldk�rteln, m�nn"
Knogle_1year_male_340_sygdomstekst                                                             <-             �"F�rb�ttring i 1-�rs cancer�verlevnad, NORDCAN\n Skelett, m�nn"
Bindevaev_1year_male_350_sygdomstekst                                                          <-             �"F�rb�ttring i 1-�rs cancer�verlevnad, NORDCAN\n Bindv�v, muskler och annan mjuk v�vnad, m�nn"
Non_Hodgkin_lymfom_1year_male_360_sygdomstekst                                                 <-             �"F�rb�ttring i 1-�rs cancer�verlevnad, NORDCAN\n Non-Hodgkin-lymfom, m�nn"
Hodgkins_lymfom_1year_male_370_sygdomstekst                                                    <-             �"F�rb�ttring i 1-�rs cancer�verlevnad, NORDCAN\n Hodgkins lymfom, m�nn"
Myelomatose_1year_male_380_sygdomstekst                                                        <-             �"F�rb�ttring i 1-�rs cancer�verlevnad, NORDCAN\n Multipelt myelom, m�nn"
Leukaemi_1year_male_400_sygdomstekst                                                           <-             �"F�rb�ttring i 1-�rs cancer�verlevnad, NORDCAN\n Leukemi, m�nn"
Akut_lymfatisk_leukaemi_1year_male_401_sygdomstekst                                            <-             �"F�rb�ttring i 1-�rs cancer�verlevnad, NORDCAN\n Akut lymfatisk leukemi, m�nn"
Kronisk_lymfatisk_leukaemi_1year_male_402_sygdomstekst                                         <-             �"F�rb�ttring i 1-�rs cancer�verlevnad, NORDCAN\n Kronisk lymfatisk leukemi, m�nn"
Anden_og_uspecificeret_lymfatisk_leukaemi_1year_male_403_sygdomstekst                          <-             �"F�rb�ttring i 1-�rs cancer�verlevnad, NORDCAN\n �vriga och icke specificerade lymfatiska leukemier, m�nn"
Akut_myeloid_leukaemi_1year_male_404_sygdomstekst                                              <-             �"F�rb�ttring i 1-�rs cancer�verlevnad, NORDCAN\n Akut myeloisk leukemi, m�nn"
Kronisk_myeloid_leukaemi_1year_male_405_sygdomstekst                                           <-             �"F�rb�ttring i 1-�rs cancer�verlevnad, NORDCAN\n Kronisk myeloisk leukemi, m�nn"
Anden_og_uspecificeret_myeloid_leukaemi_1year_male_406_sygdomstekst                            <-             �"F�rb�ttring i 1-�rs cancer�verlevnad, NORDCAN\n �vriga och ospecificerade myeloiska leukemier, m�nn"
Leukaemi_uspecificerede_celler_1year_male_407_sygdomstekst                                     <-             �"F�rb�ttring i 1-�rs cancer�verlevnad, NORDCAN\n Leukemi, ospecificerad, m�nn"
Andre_specificerede_1year_male_410_sygdomstekst                                                <-             �"F�rb�ttring i 1-�rs cancer�verlevnad, NORDCAN\n Annan specificerad, m�nn"
Ukendte_og_daarligt_definerede_1year_male_420_sygdomstekst                                     <-             �"F�rb�ttring i 1-�rs cancer�verlevnad, NORDCAN\n Ok�nd och ofullst�ndigt angiven, m�nn"
Alle_kraeftformer_undtagen_anden_hud_bryst_og_prostata_1year_male_970_sygdomstekst             <-             �"F�rb�ttring i 1-�rs cancer�verlevnad, NORDCAN\n All cancer f�rutom hudcancer (exklusive melanom), br�stcancer och prostatacancer, m�nn"
Alle_kraeftformer_1year_male_980_sygdomstekst                                                  <-             �"F�rb�ttring i 1-�rs cancer�verlevnad, NORDCAN\n Samtliga l�gen, m�nn"
Alle_kraeftformer_undtagen_anden_hud_1year_male_990_sygdomstekst                               <-             �"F�rb�ttring i 1-�rs cancer�verlevnad, NORDCAN\n Samtliga l�gen utom icke malignt melanom i huden, m�nn"
Laebe_mundhule_og_svaelg_1year_male_510_sygdomstekst                                           <-             �"F�rb�ttring i 1-�rs cancer�verlevnad, NORDCAN\n L�pp, munh�la och svalg, m�nn"
Tyk_og_endetarm_1year_male_520_sygdomstekst                                                    <-             �"F�rb�ttring i 1-�rs cancer�verlevnad, NORDCAN\n Tjock- och �ndtarm, m�nn"
Basocellulaere_carcinomer_1year_male_888_sygdomstekst                                          <-              "F�rb�ttring i 1-�rs cancer�verlevnad, NORDCAN\n Basocellular carcinomas, m�nn"
Laebe_1year_female_10_sygdomstekst                                                             <-             �"F�rb�ttring i 1-�rs cancer�verlevnad, NORDCAN\n L�pp, kvinnor"
Mundhule_1year_female_20_sygdomstekst                                                          <-             �"F�rb�ttring i 1-�rs cancer�verlevnad, NORDCAN\n Tunga, kvinnor"
Spytkirtel_1year_female_30_sygdomstekst                                                        <-             �"F�rb�ttring i 1-�rs cancer�verlevnad, NORDCAN\n Spottk�rtel, kvinnor"
Oropharynx_1year_female_40_sygdomstekst                                                        <-             �"F�rb�ttring i 1-�rs cancer�verlevnad, NORDCAN\n Mellansvalg, kvinnor"
Nasopharynx_1year_female_41_sygdomstekst                                                       <-             �"F�rb�ttring i 1-�rs cancer�verlevnad, NORDCAN\n �vre svalgrum, kvinnor"
Hypopharynx_1year_female_50_sygdomstekst                                                       <-             �"F�rb�ttring i 1-�rs cancer�verlevnad, NORDCAN\n Nedre svalg, kvinnor"
Pharynx_daarligt_defineret_1year_female_51_sygdomstekst                                        <-             �"F�rb�ttring i 1-�rs cancer�verlevnad, NORDCAN\n Svalg, ofullst�ndigt angiven, kvinnor"
Spiseror_1year_female_60_sygdomstekst                                                          <-             �"F�rb�ttring i 1-�rs cancer�verlevnad, NORDCAN\n Matstrupe, kvinnor"
Mave_1year_female_70_sygdomstekst                                                              <-             �"F�rb�ttring i 1-�rs cancer�verlevnad, NORDCAN\n Mags�ck, kvinnor"
Tyndtarm_1year_female_80_sygdomstekst                                                          <-             �"F�rb�ttring i 1-�rs cancer�verlevnad, NORDCAN\n Tunntarm, kvinnor"
Tyktarm_1year_female_90_sygdomstekst                                                           <-             �"F�rb�ttring i 1-�rs cancer�verlevnad, NORDCAN\n Tjocktarm, kvinnor"
Endetarm_og_anus_1year_female_100_sygdomstekst                                                 <-             �"F�rb�ttring i 1-�rs cancer�verlevnad, NORDCAN\n �ndtarm och anus, kvinnor"
Lever_1year_female_110_sygdomstekst                                                            <-             �"F�rb�ttring i 1-�rs cancer�verlevnad, NORDCAN\n Lever, kvinnor"
Galdeblaere_og_galdeveje_1year_female_120_sygdomstekst                                         <-             �"F�rb�ttring i 1-�rs cancer�verlevnad, NORDCAN\n Gallbl�sa och gallv�gar, kvinnor"
Bugspytkirtel_1year_female_130_sygdomstekst                                                    <-             �"F�rb�ttring i 1-�rs cancer�verlevnad, NORDCAN\n Bukspottk�rtel, kvinnor"
Naese_og_bihuler_1year_female_140_sygdomstekst                                                 <-             �"F�rb�ttring i 1-�rs cancer�verlevnad, NORDCAN\n N�sh�la och bih�lor, kvinnor"
Strube_1year_female_150_sygdomstekst                                                           <-             �"F�rb�ttring i 1-�rs cancer�verlevnad, NORDCAN\n Struphuvud, kvinnor"
Lunge_inkl_luftror_1year_female_160_sygdomstekst                                               <-             �"F�rb�ttring i 1-�rs cancer�verlevnad, NORDCAN\n Lunga (inkl. luftstrupe och luftr�r), kvinnor"
Lungehinde_1year_female_170_sygdomstekst                                                       <-             �"F�rb�ttring i 1-�rs cancer�verlevnad, NORDCAN\n Lungs�ck, kvinnor"
Bryst_1year_female_180_sygdomstekst                                                            <-             �"F�rb�ttring i 1-�rs cancer�verlevnad, NORDCAN\n Br�st, kvinnor"
Livmoderhals_1year_female_190_sygdomstekst                                                     <-             �"F�rb�ttring i 1-�rs cancer�verlevnad, NORDCAN\n Livmoderhals, kvinnor"
Livmoder_1year_female_200_sygdomstekst                                                         <-             �"F�rb�ttring i 1-�rs cancer�verlevnad, NORDCAN\n Livmoderkropp, kvinnor"
Livmoder_uden_specifikation_1year_female_210_sygdomstekst                                      <-             �"F�rb�ttring i 1-�rs cancer�verlevnad, NORDCAN\n Livmoder, ospecificerat st�lle, kvinnor"
Aeggestok_aeggeleder_mv_1year_female_220_sygdomstekst                                          <-             �"F�rb�ttring i 1-�rs cancer�verlevnad, NORDCAN\n �ggstock, �ggledare och breda livmoderbanden, kvinnor"
Ovrige_kvindelige_konsorganer_1year_female_230_sygdomstekst                                    <-             �"F�rb�ttring i 1-�rs cancer�verlevnad, NORDCAN\n �vriga kvinnliga k�nsorgan, kvinnor"
Prostata_1year_female_240_sygdomstekst                                                         <-             �"F�rb�ttring i 1-�rs cancer�verlevnad, NORDCAN\n Prostata, kvinnor"
Testikel_1year_female_250_sygdomstekst                                                         <-             �"F�rb�ttring i 1-�rs cancer�verlevnad, NORDCAN\n Testikel, kvinnor"
Penis_og_andre_mandlige_konsorganer_1year_female_260_sygdomstekst                              <-             �"F�rb�ttring i 1-�rs cancer�verlevnad, NORDCAN\n Penis och �vriga manliga k�nsorgan, kvinnor"
Nyre_1year_female_270_sygdomstekst                                                             <-             �"F�rb�ttring i 1-�rs cancer�verlevnad, NORDCAN\n Njure inklusive njurb�cken, kvinnor"
Blaere_og_andre_urinveje_1year_female_280_sygdomstekst                                         <-             �"F�rb�ttring i 1-�rs cancer�verlevnad, NORDCAN\n Urinbl�sa och �vriga urinv�gar, kvinnor"
Modermaerkekraeft_hud_1year_female_290_sygdomstekst                                            <-             �"F�rb�ttring i 1-�rs cancer�verlevnad, NORDCAN\n Malignt melanom i huden, kvinnor"
Anden_hud_ikke_modermaerke_1year_female_300_sygdomstekst                                       <-             �"F�rb�ttring i 1-�rs cancer�verlevnad, NORDCAN\n Hud, icke malignt melanom, kvinnor"
Oje_1year_female_310_sygdomstekst                                                              <-             �"F�rb�ttring i 1-�rs cancer�verlevnad, NORDCAN\n �ga, kvinnor"
Hjerne_og_centralnervesystem_1year_female_320_sygdomstekst                                     <-             �"F�rb�ttring i 1-�rs cancer�verlevnad, NORDCAN\n Hj�rna och �vriga nervsystemet, kvinnor"
Skjoldbruskkirtel_1year_female_330_sygdomstekst                                                <-             �"F�rb�ttring i 1-�rs cancer�verlevnad, NORDCAN\n Sk�ldk�rteln, kvinnor"
Knogle_1year_female_340_sygdomstekst                                                           <-             �"F�rb�ttring i 1-�rs cancer�verlevnad, NORDCAN\n Skelett, kvinnor"
Bindevaev_1year_female_350_sygdomstekst                                                        <-             �"F�rb�ttring i 1-�rs cancer�verlevnad, NORDCAN\n Bindv�v, muskler och annan mjuk v�vnad, kvinnor"
Non_Hodgkin_lymfom_1year_female_360_sygdomstekst                                               <-             �"F�rb�ttring i 1-�rs cancer�verlevnad, NORDCAN\n Non-Hodgkin-lymfom, kvinnor"
Hodgkins_lymfom_1year_female_370_sygdomstekst                                                  <-             �"F�rb�ttring i 1-�rs cancer�verlevnad, NORDCAN\n Hodgkins lymfom, kvinnor"
Myelomatose_1year_female_380_sygdomstekst                                                      <-             �"F�rb�ttring i 1-�rs cancer�verlevnad, NORDCAN\n Multipelt myelom, kvinnor"
Leukaemi_1year_female_400_sygdomstekst                                                         <-             �"F�rb�ttring i 1-�rs cancer�verlevnad, NORDCAN\n Leukemi, kvinnor"
Akut_lymfatisk_leukaemi_1year_female_401_sygdomstekst                                          <-             �"F�rb�ttring i 1-�rs cancer�verlevnad, NORDCAN\n Akut lymfatisk leukemi, kvinnor"
Kronisk_lymfatisk_leukaemi_1year_female_402_sygdomstekst                                       <-             �"F�rb�ttring i 1-�rs cancer�verlevnad, NORDCAN\n Kronisk lymfatisk leukemi, kvinnor"
Anden_og_uspecificeret_lymfatisk_leukaemi_1year_female_403_sygdomstekst                        <-             �"F�rb�ttring i 1-�rs cancer�verlevnad, NORDCAN\n �vriga och icke specificerade lymfatiska leukemier, kvinnor"
Akut_myeloid_leukaemi_1year_female_404_sygdomstekst                                            <-             �"F�rb�ttring i 1-�rs cancer�verlevnad, NORDCAN\n Akut myeloisk leukemi, kvinnor"
Kronisk_myeloid_leukaemi_1year_female_405_sygdomstekst                                         <-             �"F�rb�ttring i 1-�rs cancer�verlevnad, NORDCAN\n Kronisk myeloisk leukemi, kvinnor"
Anden_og_uspecificeret_myeloid_leukaemi_1year_female_406_sygdomstekst                          <-             �"F�rb�ttring i 1-�rs cancer�verlevnad, NORDCAN\n �vriga och ospecificerade myeloiska leukemier, kvinnor"
Leukaemi_uspecificerede_celler_1year_female_407_sygdomstekst                                   <-             �"F�rb�ttring i 1-�rs cancer�verlevnad, NORDCAN\n Leukemi, ospecificerad, kvinnor"
Andre_specificerede_1year_female_410_sygdomstekst                                              <-             �"F�rb�ttring i 1-�rs cancer�verlevnad, NORDCAN\n Annan specificerad, kvinnor"
Ukendte_og_daarligt_definerede_1year_female_420_sygdomstekst                                   <-             �"F�rb�ttring i 1-�rs cancer�verlevnad, NORDCAN\n Ok�nd och ofullst�ndigt angiven, kvinnor"
Alle_kraeftformer_undtagen_anden_hud_bryst_og_prostata_1year_female_970_sygdomstekst           <-             �"F�rb�ttring i 1-�rs cancer�verlevnad, NORDCAN\n All cancer f�rutom hudcancer (exklusive melanom), br�stcancer och prostatacancer, kvinnor"
Alle_kraeftformer_1year_female_980_sygdomstekst                                                <-             �"F�rb�ttring i 1-�rs cancer�verlevnad, NORDCAN\n Samtliga l�gen, kvinnor"
Alle_kraeftformer_undtagen_anden_hud_1year_female_990_sygdomstekst                             <-             �"F�rb�ttring i 1-�rs cancer�verlevnad, NORDCAN\n Samtliga l�gen utom icke malignt melanom i huden, kvinnor"
Laebe_mundhule_og_svaelg_1year_female_510_sygdomstekst                                         <-             �"F�rb�ttring i 1-�rs cancer�verlevnad, NORDCAN\n L�pp, munh�la och svalg, kvinnor"
Tyk_og_endetarm_1year_female_520_sygdomstekst                                                  <-             �"F�rb�ttring i 1-�rs cancer�verlevnad, NORDCAN\n Tjock- och �ndtarm, kvinnor"
Basocellulaere_carcinomer_1year_female_888_sygdomstekst                                        <-              "F�rb�ttring i 1-�rs cancer�verlevnad, NORDCAN\n Basocellular carcinomas, kvinnor"
Laebe_5year_male_10_sygdomstekst                                                               <-             �"F�rb�ttring i 5-�rs cancer�verlevnad, NORDCAN\n L�pp, m�nn"
Mundhule_5year_male_20_sygdomstekst                                                            <-             �"F�rb�ttring i 5-�rs cancer�verlevnad, NORDCAN\n Tunga, m�nn"
Spytkirtel_5year_male_30_sygdomstekst                                                          <-             �"F�rb�ttring i 5-�rs cancer�verlevnad, NORDCAN\n Spottk�rtel, m�nn"
Oropharynx_5year_male_40_sygdomstekst                                                          <-             �"F�rb�ttring i 5-�rs cancer�verlevnad, NORDCAN\n Mellansvalg, m�nn"
Nasopharynx_5year_male_41_sygdomstekst                                                         <-             �"F�rb�ttring i 5-�rs cancer�verlevnad, NORDCAN\n �vre svalgrum, m�nn"
Hypopharynx_5year_male_50_sygdomstekst                                                         <-             �"F�rb�ttring i 5-�rs cancer�verlevnad, NORDCAN\n Nedre svalg, m�nn"
Pharynx_daarligt_defineret_5year_male_51_sygdomstekst                                          <-             �"F�rb�ttring i 5-�rs cancer�verlevnad, NORDCAN\n Svalg, ofullst�ndigt angiven, m�nn"
Spiseror_5year_male_60_sygdomstekst                                                            <-             �"F�rb�ttring i 5-�rs cancer�verlevnad, NORDCAN\n Matstrupe, m�nn"
Mave_5year_male_70_sygdomstekst                                                                <-             �"F�rb�ttring i 5-�rs cancer�verlevnad, NORDCAN\n Mags�ck, m�nn"
Tyndtarm_5year_male_80_sygdomstekst                                                            <-             �"F�rb�ttring i 5-�rs cancer�verlevnad, NORDCAN\n Tunntarm, m�nn"
Tyktarm_5year_male_90_sygdomstekst                                                             <-             �"F�rb�ttring i 5-�rs cancer�verlevnad, NORDCAN\n Tjocktarm, m�nn"
Endetarm_og_anus_5year_male_100_sygdomstekst                                                   <-             �"F�rb�ttring i 5-�rs cancer�verlevnad, NORDCAN\n �ndtarm och anus, m�nn"
Lever_5year_male_110_sygdomstekst                                                              <-             �"F�rb�ttring i 5-�rs cancer�verlevnad, NORDCAN\n Lever, m�nn"
Galdeblaere_og_galdeveje_5year_male_120_sygdomstekst                                           <-             �"F�rb�ttring i 5-�rs cancer�verlevnad, NORDCAN\n Gallbl�sa och gallv�gar, m�nn"
Bugspytkirtel_5year_male_130_sygdomstekst                                                      <-             �"F�rb�ttring i 5-�rs cancer�verlevnad, NORDCAN\n Bukspottk�rtel, m�nn"
Naese_og_bihuler_5year_male_140_sygdomstekst                                                   <-             �"F�rb�ttring i 5-�rs cancer�verlevnad, NORDCAN\n N�sh�la och bih�lor, m�nn"
Strube_5year_male_150_sygdomstekst                                                             <-             �"F�rb�ttring i 5-�rs cancer�verlevnad, NORDCAN\n Struphuvud, m�nn"
Lunge_inkl_luftror_5year_male_160_sygdomstekst                                                 <-             �"F�rb�ttring i 5-�rs cancer�verlevnad, NORDCAN\n Lunga (inkl. luftstrupe och luftr�r), m�nn"
Lungehinde_5year_male_170_sygdomstekst                                                         <-             �"F�rb�ttring i 5-�rs cancer�verlevnad, NORDCAN\n Lungs�ck, m�nn"
Bryst_5year_male_180_sygdomstekst                                                              <-             �"F�rb�ttring i 5-�rs cancer�verlevnad, NORDCAN\n Br�st, m�nn"
Livmoderhals_5year_male_190_sygdomstekst                                                       <-             �"F�rb�ttring i 5-�rs cancer�verlevnad, NORDCAN\n Livmoderhals, m�nn"
Livmoder_5year_male_200_sygdomstekst                                                           <-             �"F�rb�ttring i 5-�rs cancer�verlevnad, NORDCAN\n Livmoderkropp, m�nn"
Livmoder_uden_specifikation_5year_male_210_sygdomstekst                                        <-             �"F�rb�ttring i 5-�rs cancer�verlevnad, NORDCAN\n Livmoder, ospecificerat st�lle, m�nn"
Aeggestok_aeggeleder_mv_5year_male_220_sygdomstekst                                            <-             �"F�rb�ttring i 5-�rs cancer�verlevnad, NORDCAN\n �ggstock, �ggledare och breda livmoderbanden, m�nn"
Ovrige_kvindelige_konsorganer_5year_male_230_sygdomstekst                                      <-             �"F�rb�ttring i 5-�rs cancer�verlevnad, NORDCAN\n �vriga kvinnliga k�nsorgan, m�nn"
Prostata_5year_male_240_sygdomstekst                                                           <-             �"F�rb�ttring i 5-�rs cancer�verlevnad, NORDCAN\n Prostata, m�nn"
Testikel_5year_male_250_sygdomstekst                                                           <-             �"F�rb�ttring i 5-�rs cancer�verlevnad, NORDCAN\n Testikel, m�nn"
Penis_og_andre_mandlige_konsorganer_5year_male_260_sygdomstekst                                <-             �"F�rb�ttring i 5-�rs cancer�verlevnad, NORDCAN\n Penis och �vriga manliga k�nsorgan, m�nn"
Nyre_5year_male_270_sygdomstekst                                                               <-             �"F�rb�ttring i 5-�rs cancer�verlevnad, NORDCAN\n Njure inklusive njurb�cken, m�nn"
Blaere_og_andre_urinveje_5year_male_280_sygdomstekst                                           <-             �"F�rb�ttring i 5-�rs cancer�verlevnad, NORDCAN\n Urinbl�sa och �vriga urinv�gar, m�nn"
Modermaerkekraeft_hud_5year_male_290_sygdomstekst                                              <-             �"F�rb�ttring i 5-�rs cancer�verlevnad, NORDCAN\n Malignt melanom i huden, m�nn"
Anden_hud_ikke_modermaerke_5year_male_300_sygdomstekst                                         <-             �"F�rb�ttring i 5-�rs cancer�verlevnad, NORDCAN\n Hud, icke malignt melanom, m�nn"
Oje_5year_male_310_sygdomstekst                                                                <-             �"F�rb�ttring i 5-�rs cancer�verlevnad, NORDCAN\n �ga, m�nn"
Hjerne_og_centralnervesystem_5year_male_320_sygdomstekst                                       <-             �"F�rb�ttring i 5-�rs cancer�verlevnad, NORDCAN\n Hj�rna och �vriga nervsystemet, m�nn"
Skjoldbruskkirtel_5year_male_330_sygdomstekst                                                  <-             �"F�rb�ttring i 5-�rs cancer�verlevnad, NORDCAN\n Sk�ldk�rteln, m�nn"
Knogle_5year_male_340_sygdomstekst                                                             <-             �"F�rb�ttring i 5-�rs cancer�verlevnad, NORDCAN\n Skelett, m�nn"
Bindevaev_5year_male_350_sygdomstekst                                                          <-             �"F�rb�ttring i 5-�rs cancer�verlevnad, NORDCAN\n Bindv�v, muskler och annan mjuk v�vnad, m�nn"
Non_Hodgkin_lymfom_5year_male_360_sygdomstekst                                                 <-             �"F�rb�ttring i 5-�rs cancer�verlevnad, NORDCAN\n Non-Hodgkin-lymfom, m�nn"
Hodgkins_lymfom_5year_male_370_sygdomstekst                                                    <-             �"F�rb�ttring i 5-�rs cancer�verlevnad, NORDCAN\n Hodgkins lymfom, m�nn"
Myelomatose_5year_male_380_sygdomstekst                                                        <-             �"F�rb�ttring i 5-�rs cancer�verlevnad, NORDCAN\n Multipelt myelom, m�nn"
Leukaemi_5year_male_400_sygdomstekst                                                           <-             �"F�rb�ttring i 5-�rs cancer�verlevnad, NORDCAN\n Leukemi, m�nn"
Akut_lymfatisk_leukaemi_5year_male_401_sygdomstekst                                            <-             �"F�rb�ttring i 5-�rs cancer�verlevnad, NORDCAN\n Akut lymfatisk leukemi, m�nn"
Kronisk_lymfatisk_leukaemi_5year_male_402_sygdomstekst                                         <-             �"F�rb�ttring i 5-�rs cancer�verlevnad, NORDCAN\n Kronisk lymfatisk leukemi, m�nn"
Anden_og_uspecificeret_lymfatisk_leukaemi_5year_male_403_sygdomstekst                          <-             �"F�rb�ttring i 5-�rs cancer�verlevnad, NORDCAN\n �vriga och icke specificerade lymfatiska leukemier, m�nn"
Akut_myeloid_leukaemi_5year_male_404_sygdomstekst                                              <-             �"F�rb�ttring i 5-�rs cancer�verlevnad, NORDCAN\n Akut myeloisk leukemi, m�nn"
Kronisk_myeloid_leukaemi_5year_male_405_sygdomstekst                                           <-             �"F�rb�ttring i 5-�rs cancer�verlevnad, NORDCAN\n Kronisk myeloisk leukemi, m�nn"
Anden_og_uspecificeret_myeloid_leukaemi_5year_male_406_sygdomstekst                            <-             �"F�rb�ttring i 5-�rs cancer�verlevnad, NORDCAN\n �vriga och ospecificerade myeloiska leukemier, m�nn"
Leukaemi_uspecificerede_celler_5year_male_407_sygdomstekst                                     <-             �"F�rb�ttring i 5-�rs cancer�verlevnad, NORDCAN\n Leukemi, ospecificerad, m�nn"
Andre_specificerede_5year_male_410_sygdomstekst                                                <-             �"F�rb�ttring i 5-�rs cancer�verlevnad, NORDCAN\n Annan specificerad, m�nn"
Ukendte_og_daarligt_definerede_5year_male_420_sygdomstekst                                     <-             �"F�rb�ttring i 5-�rs cancer�verlevnad, NORDCAN\n Ok�nd och ofullst�ndigt angiven, m�nn"
Alle_kraeftformer_undtagen_anden_hud_bryst_og_prostata_5year_male_970_sygdomstekst             <-             �"F�rb�ttring i 5-�rs cancer�verlevnad, NORDCAN\n All cancer f�rutom hudcancer (exklusive melanom), br�stcancer och prostatacancer, m�nn"
Alle_kraeftformer_5year_male_980_sygdomstekst                                                  <-             �"F�rb�ttring i 5-�rs cancer�verlevnad, NORDCAN\n Samtliga l�gen, m�nn"
Alle_kraeftformer_undtagen_anden_hud_5year_male_990_sygdomstekst                               <-             �"F�rb�ttring i 5-�rs cancer�verlevnad, NORDCAN\n Samtliga l�gen utom icke malignt melanom i huden, m�nn"
Laebe_mundhule_og_svaelg_5year_male_510_sygdomstekst                                           <-             �"F�rb�ttring i 5-�rs cancer�verlevnad, NORDCAN\n L�pp, munh�la och svalg, m�nn"
Tyk_og_endetarm_5year_male_520_sygdomstekst                                                    <-             �"F�rb�ttring i 5-�rs cancer�verlevnad, NORDCAN\n Tjock- och �ndtarm, m�nn"
Basocellulaere_carcinomer_5year_male_888_sygdomstekst                                          <-              "F�rb�ttring i 5-�rs cancer�verlevnad, NORDCAN\n Basocellular carcinomas, m�nn"
Laebe_5year_female_10_sygdomstekst                                                             <-             �"F�rb�ttring i 5-�rs cancer�verlevnad, NORDCAN\n L�pp, kvinnor"
Mundhule_5year_female_20_sygdomstekst                                                          <-             �"F�rb�ttring i 5-�rs cancer�verlevnad, NORDCAN\n Tunga, kvinnor"
Spytkirtel_5year_female_30_sygdomstekst                                                        <-             �"F�rb�ttring i 5-�rs cancer�verlevnad, NORDCAN\n Spottk�rtel, kvinnor"
Oropharynx_5year_female_40_sygdomstekst                                                        <-             �"F�rb�ttring i 5-�rs cancer�verlevnad, NORDCAN\n Mellansvalg, kvinnor"
Nasopharynx_5year_female_41_sygdomstekst                                                       <-             �"F�rb�ttring i 5-�rs cancer�verlevnad, NORDCAN\n �vre svalgrum, kvinnor"
Hypopharynx_5year_female_50_sygdomstekst                                                       <-             �"F�rb�ttring i 5-�rs cancer�verlevnad, NORDCAN\n Nedre svalg, kvinnor"
Pharynx_daarligt_defineret_5year_female_51_sygdomstekst                                        <-             �"F�rb�ttring i 5-�rs cancer�verlevnad, NORDCAN\n Svalg, ofullst�ndigt angiven, kvinnor"
Spiseror_5year_female_60_sygdomstekst                                                          <-             �"F�rb�ttring i 5-�rs cancer�verlevnad, NORDCAN\n Matstrupe, kvinnor"
Mave_5year_female_70_sygdomstekst                                                              <-             �"F�rb�ttring i 5-�rs cancer�verlevnad, NORDCAN\n Mags�ck, kvinnor"
Tyndtarm_5year_female_80_sygdomstekst                                                          <-             �"F�rb�ttring i 5-�rs cancer�verlevnad, NORDCAN\n Tunntarm, kvinnor"
Tyktarm_5year_female_90_sygdomstekst                                                           <-             �"F�rb�ttring i 5-�rs cancer�verlevnad, NORDCAN\n Tjocktarm, kvinnor"
Endetarm_og_anus_5year_female_100_sygdomstekst                                                 <-             �"F�rb�ttring i 5-�rs cancer�verlevnad, NORDCAN\n �ndtarm och anus, kvinnor"
Lever_5year_female_110_sygdomstekst                                                            <-             �"F�rb�ttring i 5-�rs cancer�verlevnad, NORDCAN\n Lever, kvinnor"
Galdeblaere_og_galdeveje_5year_female_120_sygdomstekst                                         <-             �"F�rb�ttring i 5-�rs cancer�verlevnad, NORDCAN\n Gallbl�sa och gallv�gar, kvinnor"
Bugspytkirtel_5year_female_130_sygdomstekst                                                    <-             �"F�rb�ttring i 5-�rs cancer�verlevnad, NORDCAN\n Bukspottk�rtel, kvinnor"
Naese_og_bihuler_5year_female_140_sygdomstekst                                                 <-             �"F�rb�ttring i 5-�rs cancer�verlevnad, NORDCAN\n N�sh�la och bih�lor, kvinnor"
Strube_5year_female_150_sygdomstekst                                                           <-             �"F�rb�ttring i 5-�rs cancer�verlevnad, NORDCAN\n Struphuvud, kvinnor"
Lunge_inkl_luftror_5year_female_160_sygdomstekst                                               <-             �"F�rb�ttring i 5-�rs cancer�verlevnad, NORDCAN\n Lunga (inkl. luftstrupe och luftr�r), kvinnor"
Lungehinde_5year_female_170_sygdomstekst                                                       <-             �"F�rb�ttring i 5-�rs cancer�verlevnad, NORDCAN\n Lungs�ck, kvinnor"
Bryst_5year_female_180_sygdomstekst                                                            <-             �"F�rb�ttring i 5-�rs cancer�verlevnad, NORDCAN\n Br�st, kvinnor"
Livmoderhals_5year_female_190_sygdomstekst                                                     <-             �"F�rb�ttring i 5-�rs cancer�verlevnad, NORDCAN\n Livmoderhals, kvinnor"
Livmoder_5year_female_200_sygdomstekst                                                         <-             �"F�rb�ttring i 5-�rs cancer�verlevnad, NORDCAN\n Livmoderkropp, kvinnor"
Livmoder_uden_specifikation_5year_female_210_sygdomstekst                                      <-             �"F�rb�ttring i 5-�rs cancer�verlevnad, NORDCAN\n Livmoder, ospecificerat st�lle, kvinnor"
Aeggestok_aeggeleder_mv_5year_female_220_sygdomstekst                                          <-             �"F�rb�ttring i 5-�rs cancer�verlevnad, NORDCAN\n �ggstock, �ggledare och breda livmoderbanden, kvinnor"
Ovrige_kvindelige_konsorganer_5year_female_230_sygdomstekst                                    <-             �"F�rb�ttring i 5-�rs cancer�verlevnad, NORDCAN\n �vriga kvinnliga k�nsorgan, kvinnor"
Prostata_5year_female_240_sygdomstekst                                                         <-             �"F�rb�ttring i 5-�rs cancer�verlevnad, NORDCAN\n Prostata, kvinnor"
Testikel_5year_female_250_sygdomstekst                                                         <-             �"F�rb�ttring i 5-�rs cancer�verlevnad, NORDCAN\n Testikel, kvinnor"
Penis_og_andre_mandlige_konsorganer_5year_female_260_sygdomstekst                              <-             �"F�rb�ttring i 5-�rs cancer�verlevnad, NORDCAN\n Penis och �vriga manliga k�nsorgan, kvinnor"
Nyre_5year_female_270_sygdomstekst                                                             <-             �"F�rb�ttring i 5-�rs cancer�verlevnad, NORDCAN\n Njure inklusive njurb�cken, kvinnor"
Blaere_og_andre_urinveje_5year_female_280_sygdomstekst                                         <-             �"F�rb�ttring i 5-�rs cancer�verlevnad, NORDCAN\n Urinbl�sa och �vriga urinv�gar, kvinnor"
Modermaerkekraeft_hud_5year_female_290_sygdomstekst                                            <-             �"F�rb�ttring i 5-�rs cancer�verlevnad, NORDCAN\n Malignt melanom i huden, kvinnor"
Anden_hud_ikke_modermaerke_5year_female_300_sygdomstekst                                       <-             �"F�rb�ttring i 5-�rs cancer�verlevnad, NORDCAN\n Hud, icke malignt melanom, kvinnor"
Oje_5year_female_310_sygdomstekst                                                              <-             �"F�rb�ttring i 5-�rs cancer�verlevnad, NORDCAN\n �ga, kvinnor"
Hjerne_og_centralnervesystem_5year_female_320_sygdomstekst                                     <-             �"F�rb�ttring i 5-�rs cancer�verlevnad, NORDCAN\n Hj�rna och �vriga nervsystemet, kvinnor"
Skjoldbruskkirtel_5year_female_330_sygdomstekst                                                <-             �"F�rb�ttring i 5-�rs cancer�verlevnad, NORDCAN\n Sk�ldk�rteln, kvinnor"
Knogle_5year_female_340_sygdomstekst                                                           <-             �"F�rb�ttring i 5-�rs cancer�verlevnad, NORDCAN\n Skelett, kvinnor"
Bindevaev_5year_female_350_sygdomstekst                                                        <-             �"F�rb�ttring i 5-�rs cancer�verlevnad, NORDCAN\n Bindv�v, muskler och annan mjuk v�vnad, kvinnor"
Non_Hodgkin_lymfom_5year_female_360_sygdomstekst                                               <-             �"F�rb�ttring i 5-�rs cancer�verlevnad, NORDCAN\n Non-Hodgkin-lymfom, kvinnor"
Hodgkins_lymfom_5year_female_370_sygdomstekst                                                  <-             �"F�rb�ttring i 5-�rs cancer�verlevnad, NORDCAN\n Hodgkins lymfom, kvinnor"
Myelomatose_5year_female_380_sygdomstekst                                                      <-             �"F�rb�ttring i 5-�rs cancer�verlevnad, NORDCAN\n Multipelt myelom, kvinnor"
Leukaemi_5year_female_400_sygdomstekst                                                         <-             �"F�rb�ttring i 5-�rs cancer�verlevnad, NORDCAN\n Leukemi, kvinnor"
Akut_lymfatisk_leukaemi_5year_female_401_sygdomstekst                                          <-             �"F�rb�ttring i 5-�rs cancer�verlevnad, NORDCAN\n Akut lymfatisk leukemi, kvinnor"
Kronisk_lymfatisk_leukaemi_5year_female_402_sygdomstekst                                       <-             �"F�rb�ttring i 5-�rs cancer�verlevnad, NORDCAN\n Kronisk lymfatisk leukemi, kvinnor"
Anden_og_uspecificeret_lymfatisk_leukaemi_5year_female_403_sygdomstekst                        <-             �"F�rb�ttring i 5-�rs cancer�verlevnad, NORDCAN\n �vriga och icke specificerade lymfatiska leukemier, kvinnor"
Akut_myeloid_leukaemi_5year_female_404_sygdomstekst                                            <-             �"F�rb�ttring i 5-�rs cancer�verlevnad, NORDCAN\n Akut myeloisk leukemi, kvinnor"
Kronisk_myeloid_leukaemi_5year_female_405_sygdomstekst                                         <-             �"F�rb�ttring i 5-�rs cancer�verlevnad, NORDCAN\n Kronisk myeloisk leukemi, kvinnor"
Anden_og_uspecificeret_myeloid_leukaemi_5year_female_406_sygdomstekst                          <-             �"F�rb�ttring i 5-�rs cancer�verlevnad, NORDCAN\n �vriga och ospecificerade myeloiska leukemier, kvinnor"
Leukaemi_uspecificerede_celler_5year_female_407_sygdomstekst                                   <-             �"F�rb�ttring i 5-�rs cancer�verlevnad, NORDCAN\n Leukemi, ospecificerad, kvinnor"
Andre_specificerede_5year_female_410_sygdomstekst                                              <-             �"F�rb�ttring i 5-�rs cancer�verlevnad, NORDCAN\n Annan specificerad, kvinnor"
Ukendte_og_daarligt_definerede_5year_female_420_sygdomstekst                                   <-             �"F�rb�ttring i 5-�rs cancer�verlevnad, NORDCAN\n Ok�nd och ofullst�ndigt angiven, kvinnor"
Alle_kraeftformer_undtagen_anden_hud_bryst_og_prostata_5year_female_970_sygdomstekst           <-             �"F�rb�ttring i 5-�rs cancer�verlevnad, NORDCAN\n All cancer f�rutom hudcancer (exklusive melanom), br�stcancer och prostatacancer, kvinnor"
Alle_kraeftformer_5year_female_980_sygdomstekst                                                <-             �"F�rb�ttring i 5-�rs cancer�verlevnad, NORDCAN\n Samtliga l�gen, kvinnor"
Alle_kraeftformer_undtagen_anden_hud_5year_female_990_sygdomstekst                             <-             �"F�rb�ttring i 5-�rs cancer�verlevnad, NORDCAN\n Samtliga l�gen utom icke malignt melanom i huden, kvinnor"
Laebe_mundhule_og_svaelg_5year_female_510_sygdomstekst                                         <-             �"F�rb�ttring i 5-�rs cancer�verlevnad, NORDCAN\n L�pp, munh�la och svalg, kvinnor"
Tyk_og_endetarm_5year_female_520_sygdomstekst                                                  <-             �"F�rb�ttring i 5-�rs cancer�verlevnad, NORDCAN\n Tjock- och �ndtarm, kvinnor"
Basocellulaere_carcinomer_5year_female_888_sygdomstekst                                        <-              "F�rb�ttring i 5-�rs cancer�verlevnad, NORDCAN\n Basocellular carcinomas, kvinnor"




































































































































































































































